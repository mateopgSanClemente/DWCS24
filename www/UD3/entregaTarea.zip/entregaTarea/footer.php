<footer class="bg-dark text-white text-center col-sm-12 py-3">
    <p>&#169 Mateo Pastor González</p>
    <a href="index.php" class="btn btn-primary">Página principal</a>
</footer>