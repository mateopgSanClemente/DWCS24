<aside class="col-md-3 col-lg-3 bg-light p-3">
    <div class="container pt-3 pb-2 mb-3 border-bottom">
        <h2>Menú</h2>
    </div>
    <ul class="list-group">
        <li class="list-group-item"><a class="nav-link" href="index.php">Página principal</a></li>
        <li class="list-group-item"><a class="nav-link" href="init.php">Iniciar base de datos y tabla</a></li>
        <li class="list-group-item"><a class="nav-link" href="nuevoUsuarioForm.php">Nuevo usuario</a></li>
        <li class="list-group-item"><a class="nav-link" href="usuarios.php">Listar usuarios</a></li>
        <li class="list-group-item"><a class="nav-link" href="nuevaForm.php">Nueva tarea</a></li>
        <li class="list-group-item"><a class="nav-link" href="tareas.php">Listar tareas</a></li>
    </ul>
</aside>