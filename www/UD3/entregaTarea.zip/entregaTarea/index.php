<?php include_once("head.php"); ?>
<body>
    <!-- header -->
    <?php include_once ('header.php');?>
    <div class="container-fluid d-flex flex-column">
        <div class="row">
            <!-- menu -->
            <?php
                include_once('menu.php');
            ?>
            <main class="col-md-9 main-content">
                <div class="pt-4 pb-2 mb-3 border-bottom">
                    <h2>Sobre mí</h2>
                </div>
                <p>Mi nombre es <b>Mateo Pastor González</b> y estoy cursando la asignatura <b>DWCS</b>.</p>
            </main>
        </div>

    </div>
    <!-- footer -->
    <?php include_once ('footer.php'); ?>
</body>
</html>